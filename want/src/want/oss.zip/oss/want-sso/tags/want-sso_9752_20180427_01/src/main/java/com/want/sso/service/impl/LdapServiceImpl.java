/*
 * -------------------------------------------------------
 * @FileName LdapServiceImpl.java
 * @Description ladp操作service实现类
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.service.impl;

import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.stereotype.Service;

import com.want.sso.pojo.User;
import com.want.sso.service.ILdapService;

/**
 * @description ladp相关操作service实现类
 * @author 00294476
 * @version V1.0.0
 */
@Service
public class LdapServiceImpl implements ILdapService {

	@Value(value = "${ad.ldap.user.dn}")
	private String ldapUserDn;

	// ldap模板类注入
	@Autowired
	private LdapTemplate ldapTemplate;

	/*
	 * (non-Javadoc) <LDAPAD登录验证>
	 * 
	 * @see com.want.sso.service.ILdapService#loginAD(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public boolean loginAD(String account, String password) {
		if (StringUtils.isEmpty(account) || StringUtils.isEmpty(password)) {
			return false;
		} else {
			String filter = "(&(objectclass=person)(cn=" + account + "))";
			// 到ldap进行验证
			return ldapTemplate.authenticate(ldapUserDn, filter, password);
		}
	}

	/**
	 * <判断是否是经销商>
	 */
	@Override
	public boolean isCustomer(String userId) {
		User customer = getUserInfo(userId);
		if (customer == null) {
			return false;
		}
		if (StringUtils.contains(customer.getDistinguishedName(), "经销商")
				|| StringUtils.contains(customer.getDistinguishedName(), "县城非送旺客户")
				|| StringUtils.contains(customer.getDistinguishedName(), "非送旺客户")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * <获取经销商信息>
	 */
	@Override
	public User getUserInfo(String userId) {

		String filter = "(cn=" + userId + ")";
		// 从ldap中获取用户信息
		List<User> userList = ldapTemplate.search(ldapUserDn, filter, new AttributesMapper<User>() {

			@Override
			public User mapFromAttributes(Attributes attributes) throws NamingException {
				User customer = new User();

				Attribute attribute = attributes.get("sn");// 姓名
				if (null != attribute)
					customer.setUserName((String) (attribute.get()));

				attribute = attributes.get("cn");// 工号
				if (null != attribute)
					customer.setUserId((String) (attribute.get()));

				attribute = attributes.get("distinguishedName");// dn
				if (null != attribute)
					customer.setDistinguishedName((String) (attribute.get()));

				return customer;
			}
		});

		return userList.get(0);
	}

}
