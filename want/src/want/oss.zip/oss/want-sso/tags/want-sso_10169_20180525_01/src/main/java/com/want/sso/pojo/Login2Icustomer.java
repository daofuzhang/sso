package com.want.sso.pojo;

public class Login2Icustomer {

	private String key;//系统互信key
	
	private String vt;//登入到新的经销商系统共用的vt
	
	private String url; //跳转到爱旺旺的URL
	
	private String signId; //跳转到爱旺旺的签名

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getVt() {
		return vt;
	}

	public void setVt(String vt) {
		this.vt = vt;
	}

	public String getSignId() {
		return signId;
	}

	public void setSignId(String signId) {
		this.signId = signId;
	}

	@Override
	public String toString() {
		return "Login2Icustomer [key=" + key + ", vt=" + vt + ", url=" + url + ", signId=" + signId + "]";
	}
	
}
