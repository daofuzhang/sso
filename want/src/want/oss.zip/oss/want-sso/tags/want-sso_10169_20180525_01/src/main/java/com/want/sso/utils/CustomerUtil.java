package com.want.sso.utils;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.sso.pojo.Login2Icustomer;

public class CustomerUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerUtil.class);
	/**
	 * 
	 * <p>Description:将经销商的帐号格式化：去掉末尾-1,前边补上00 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月4日 上午9:49:41
	 * @param customerId
	 * @return
	 */
	public static String customerIdFormat(String customerId){
		if (StringUtils.isNoneBlank(customerId)) {
			customerId = "00" + customerId.substring(0, customerId.length()-2);
		}
		return customerId;
	}
	/**
	 * 
	 * <p>Description:将经销商的帐号格式化：去掉前边00,前边补上-1便于ldap校验 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月4日 上午9:49:41
	 * @param customerId
	 * @return
	 */
	public static String customerIdFormatForLdap(String customerId){
		if (StringUtils.isNoneBlank(customerId)) {
			customerId = customerId.substring(2, customerId.length())+"-1";
		}
		return customerId;
	}
	
	/**
	 * 
	 * <p>Description:爱旺旺登入到经销商网站请求的json格式:
	 * {"key":"8cfeed20e22947e2b314987be3c7a557","vt":"8cfeed20e22947e2b314987be3c7a557","url":"","signId":"6AD0C590FCE13356E053E11A000A3E05_Want2Icustomer"}
	 * 参数说明：
	 * key：不能为空，为系统互信的token
	 * vt:可以为空，若不为空则经销商网站共用一个这个vt
	 * url:跳转到经销商网站的URL，若空默认到主页
	 * signId：返回爱旺旺的签名 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月27日 下午4:39:34
	 * @param vt
	 * @param url
	 * @param want2IcustomerSignId
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String makeIcustomerJson(String vt, String url, String want2IcustomerSignId) throws UnsupportedEncodingException {
		
		Login2Icustomer login2Icustomer = new Login2Icustomer();
		
		//自定义互信规则key
		if (StringUtils.isNoneBlank(vt)) {
			login2Icustomer.setKey(vt);
			login2Icustomer.setVt(vt);
		}
		
		//默认为空直接跳到经销商的portal页面
		if (StringUtils.isNoneBlank(url)) {
			
			login2Icustomer.setUrl(url);
		}else{
			
			login2Icustomer.setUrl("");
		}
		
		//登入经销商的签名
		login2Icustomer.setSignId(want2IcustomerSignId);
		
        ObjectMapper mapper = new ObjectMapper();
        String mapJakcson = "";
		try {
			mapJakcson = mapper.writeValueAsString(login2Icustomer);
		} catch (JsonProcessingException e) {
			LOGGER.error("爱旺旺登入到经销商网站拼接json的时候出现异常");
			e.printStackTrace();
		}
		return mapJakcson;
	}
}
