package com.want.sso.pojo;

public class WantWebServiceData {

	private String data;
	
	private String status;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "WantWebServiceData [data=" + data + ", status=" + status + "]";
	}
}
