/*
 * -------------------------------------------------------
 * @FileName ILdapService.java
 * @Description ILdapService接口
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.service;

import com.want.sso.pojo.User;

/**
 * @description ladp相关操作service
 * @author 00294476
 * @version V1.0.0
 */
public interface ILdapService {

    /**
     * <LDAPAD登录验证>
     * 
     * @param account
     * @param password
     * @return
     */
    boolean loginAD(String account, String password);

    /**
     * <判断是否是经销商>
     * @param userId
     * @return
     */
    boolean isCustomer(String userId);
    
    /**
     * <判断是否在ldap中存在，在User那一栏位下边>
     * @param userId
     * @return
     */
    boolean isUser(String userId);

    /**
     * <获取员工信息>
     * @param userId
     * @return
     */
    User getUserInfo(String userId);

}
