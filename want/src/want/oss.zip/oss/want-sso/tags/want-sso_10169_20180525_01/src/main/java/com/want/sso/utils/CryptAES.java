/**  
 * @Title: JM.java
 * @Prject: discuss
 * @Package: com.want.discuss.util
 * @Description: TODO
 * @author: 00294476  
 * @date: 2017年07月03日20:06:20
 * @version: V1.0  
 * Copyright © www.want-want.com Inc. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 */
package com.want.sso.utils;

import java.security.Key;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * 加密工具类
 * @author 00319159
 * 下午8:05:24
 *  旺旺集团
 */
public class CryptAES {

	private static final String AESTYPE = "AES/ECB/PKCS5Padding";

	public static String AES_Encrypt(String keyStr, String plainText) {
		byte[] encrypt = null;
		try {
			Key key = generateKey(keyStr);
			Cipher cipher = Cipher.getInstance(AESTYPE);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			encrypt = cipher.doFinal(plainText.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String(Base64.encodeBase64(encrypt));
	}

	public static String AES_Decrypt(String keyStr, String encryptData) {
		byte[] decrypt = null;
		try {
			Key key = generateKey(keyStr);
			Cipher cipher = Cipher.getInstance(AESTYPE);
			cipher.init(Cipher.DECRYPT_MODE, key);
			decrypt = cipher.doFinal(Base64.decodeBase64(encryptData));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String(decrypt).trim();
	}

	private static Key generateKey(String key) throws Exception {
		try {
			SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), "AES");
			return keySpec;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void main(String[] args) {
		String aes_Encrypt = CryptAES.AES_Encrypt("1234567890123456", "11234321");
		System.out.println(aes_Encrypt);
		String aes_Decrypt = CryptAES.AES_Decrypt("1234567890123456", aes_Encrypt);
		System.out.println(aes_Decrypt);
	}
	
	
}
