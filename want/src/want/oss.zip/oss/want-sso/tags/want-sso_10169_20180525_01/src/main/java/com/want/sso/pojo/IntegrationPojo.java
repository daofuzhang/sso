package com.want.sso.pojo;
/**
 * 系统集成实体类
 */
public class IntegrationPojo {

	private String id;
	private String empName;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	
}
