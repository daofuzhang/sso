/*
 * -------------------------------------------------------
 * @FileName PageController.java
 * @Description 通用页面跳转器
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @description 通用页面跳转器
 * @author 00294476
 * @version V1.0.0
 */
@Controller
@RequestMapping(value = "page")
public class PageController {

	/**
	 * <页面跳转>
	 * 
	 * @param page
	 * @return 要跳转到的页面
	 */
	@RequestMapping(value = "{page}", method = RequestMethod.GET)
	public String toPage(@PathVariable(value = "page") String page) {
		return page;
	}
}
