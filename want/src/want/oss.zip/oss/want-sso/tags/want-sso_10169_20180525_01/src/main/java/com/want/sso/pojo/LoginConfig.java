/*
 * -------------------------------------------------------
 * @FileName LoginConfig.java
 * @Description 登录配置信息类
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.pojo;

import com.want.common.pojo.SsoBaseConfig;

/**
 * @description 登录拦截器的配置信息
 * @author 00294476
 * @version V1.0.0
 */
public class LoginConfig extends SsoBaseConfig {

	private String ltCookieName;

	private int ltRedisMaxTime;

	private int ltCookieMaxTime;

	private String loginViewName;// 登录的视图

	private String portalUrl;// 主页的url

	public String getLtCookieName() {
		return ltCookieName;
	}

	public void setLtCookieName(String ltCookieName) {
		this.ltCookieName = ltCookieName;
	}

	public int getLtRedisMaxTime() {
		return ltRedisMaxTime;
	}

	public void setLtRedisMaxTime(int ltRedisMaxTime) {
		this.ltRedisMaxTime = ltRedisMaxTime;
	}

	public int getLtCookieMaxTime() {
		return ltCookieMaxTime;
	}

	public void setLtCookieMaxTime(int ltCookieMaxTime) {
		this.ltCookieMaxTime = ltCookieMaxTime;
	}

	public String getLoginViewName() {
		return loginViewName;
	}

	public void setLoginViewName(String loginViewName) {
		this.loginViewName = loginViewName;
	}

	public String getPortalUrl() {
		return portalUrl;
	}

	public void setPortalUrl(String portalUrl) {
		this.portalUrl = portalUrl;
	}
}
