
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;

public class Test {

    public static void main(String[] args) {

        LdapContextSource contextSource = new LdapContextSource();
        contextSource.setUrl("ldap://10.0.26.145:7389");
        contextSource.setUserDn("CN=ron,CN=Partition1,DC=want-moss,DC=com");
        contextSource.setPassword("123456");
        contextSource.afterPropertiesSet();

        LdapTemplate ldapTemplate = new LdapTemplate(contextSource);
        try {
            ldapTemplate.afterPropertiesSet();
        } catch (Exception e) {
            e.printStackTrace();
        }
        AndFilter filter = new AndFilter(); 
        filter.and(new EqualsFilter("objectclass", "person")).and(new EqualsFilter( "cn", "00294476"));
        //String filter = "(&(objectclass=person)(cn=00294476))";
        boolean authed1 = ldapTemplate.authenticate("CN=Users,CN=Partition1,DC=want-moss,DC=com", filter.toString(), "P@ssw0rd");
        boolean authed2 = ldapTemplate.authenticate("CN=Users,CN=Partition1,DC=want-moss,DC=com", filter.toString(), "");
        boolean authed3 = ldapTemplate.authenticate("CN=Users,CN=Partition1,DC=want-moss,DC=com", filter.toString(), "  ");
        boolean authed4 = ldapTemplate.authenticate("CN=Users,CN=Partition1,DC=want-moss,DC=com", filter.toString(), "password");
        System.out.println(""+authed1+" "+authed2+" "+authed3+" "+authed4);
    }

}
