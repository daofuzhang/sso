package com.want.sso.utils;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/**
 * 
 * <p>Title:工具类 </p>
 * <p>Description:爱旺旺系统第三方系统集成自己系统的互信加解密工具</p>
 * <p>Company:旺旺集团</p>
 * @author 00301082
 * @date 2018年4月24日 下午1:54:47
 */
public class WantDes4Sso {
  
    /**
     * 
     * <p>Description:DES加密：
     * 1.先用DES加密
     * 2.将加密后的字节转十六进制
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月24日 下午1:23:39
     * @param content
     * @param keyBytes
     * @return
     */
    public static String DES_CBC_Encrypt(String content, String keyBytes){        
        try {  
            DESKeySpec keySpec=new DESKeySpec(keyBytes.getBytes());  
            SecretKeyFactory keyFactory=SecretKeyFactory.getInstance("DES");              
            SecretKey key=keyFactory.generateSecret(keySpec);         
              
            Cipher cipher=Cipher.getInstance("DES/CBC/PKCS5Padding");  
            cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(keySpec.getKey()));             
            byte[] result=cipher.doFinal(content.getBytes("UTF-8"));  
            return Base64.getEncoder().encodeToString(result);  
        } catch (Exception e) {  
            e.printStackTrace();
        }  
        return null;  
    }  
      
    /**
     * 
     * <p>Description:解密DES：
     * 1.字符串通过十六进制转字节
     * 2.将字节用DES解密
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月24日 下午1:24:41
     * @param content
     * @param keyBytes
     * @return
     */
    public static String DES_CBC_Decrypt(String content, String keyBytes){        
        try {  
            DESKeySpec keySpec=new DESKeySpec(keyBytes.getBytes("UTF-8"));  
            SecretKeyFactory keyFactory=SecretKeyFactory.getInstance("DES");  
            SecretKey key=keyFactory.generateSecret(keySpec);  
              
            Cipher cipher=Cipher.getInstance("DES/CBC/PKCS5Padding");  
            cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(keyBytes.getBytes("UTF-8")));  
            byte[] result=cipher.doFinal(Base64.getDecoder().decode(content));  
            return new String(result,"UTF-8");  
        } catch (Exception e) {  
        	e.printStackTrace();
        }  
        return null;  
    }  
      
    /**
     * 
     * <p>Description:字节转成十六进制 </p>
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月24日 下午1:12:09
     * @param bytes
     * @return
     */
    public static String byteToHexString(byte[] bytes) {  
        StringBuffer sb = new StringBuffer(bytes.length);  
        String sTemp;  
        for (int i = 0; i < bytes.length; i++) {  
            sTemp = Integer.toHexString(0xFF & bytes[i]);  
            if (sTemp.length() < 2)  
                sb.append(0);  
            sb.append(sTemp.toUpperCase());  
        }  
        return sb.toString();  
    }  
        
    /**
     * 
     * <p>Description:十六进制转字节 </p>
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月24日 下午1:12:42
     * @param s
     * @return
     */
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        try {
            for (int i = 0; i < len; i += 2) {
                data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                        + Character.digit(s.charAt(i+1), 16));
            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return data;
    }
    
}
