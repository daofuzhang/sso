/*
 * -------------------------------------------------------
 * @FileName SysIntegtateController.java
 * @Description HR系统集成
 * @Author 00306219
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.common.pojo.SsoUser;
import com.want.common.service.RedisService;
import com.want.common.util.CookieUtil;
import com.want.common.util.ExceptionUtil;
import com.want.sso.pojo.LoginConfig;
import com.want.sso.utils.CryptAES;

@Controller
@RequestMapping(value = "hr_integration")
public class SysIntegrateHRController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	//考试系统URL
	@Value(value = "${examinationUrl}")
    private String examinationUrl;
	
	@Autowired
	private LoginConfig loginConfig;

	@Autowired
	private RedisService redisService;

	/**
	 * 考试系统集成
	 * @author 00306219
	 * 下午4:35:40
	 * @param response
	 * @param vt
	 * @return 
	 * @throws Exception
	 *  旺旺集团
	 */
	@RequestMapping(value="examination")
    public ModelAndView discussLogin(HttpServletResponse response,HttpServletRequest request) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		String backUrl = "";
		// 从cookie中获取vt
		String vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		 // 获取当前登录人员信息
        SsoUser ssoUser = this.getUserByVtUseVt(request,backUrl,vt);
    	if(ssoUser==null){
       		this.validateFailed(backUrl, mv);
       	}else{
			String plainText = ssoUser.getAccount();
			LOGGER.info("account({}) 用户工号!", plainText);
			//生成16位随机字符串
			String keyStr = this.keyStrUtil();
			LOGGER.info("生成16位随机字符串({})", keyStr);
			//加密工号
			String encUserCode = CryptAES.AES_Encrypt(keyStr, plainText);
			LOGGER.info("加密工号({}) ", encUserCode);
			
			//设置cookie
			Cookie cookie = new Cookie("examUserCode", URLEncoder.encode(encUserCode, "UTF-8"));
			cookie.setDomain("want-want.com");
			cookie.setPath("/");
	        response.addCookie(cookie);
	        mv = new ModelAndView("redirect:"+examinationUrl+keyStr);
       	}
        return mv;
    }
	
	/**
	 * 人事系统集成和ear包通信的方法
	 * 
	 * @param httpServletRequest
	 * @param vt
	 * @return IntegrationPojo
	 * @throws Exception 
	 */
	@RequestMapping(value = "validate_service", method = RequestMethod.POST)
	@ResponseBody
	public String systemIntegration(HttpServletRequest request,HttpServletResponse response) {
		String vt = request.getParameter("vt");
		try {
			SsoUser ssoUser = this.getUserByVtUseVt(request, "", vt);
			String account = ssoUser.getAccount();
			LOGGER.info("account({}) 用户工号!", account);
			response.setContentType("text/html;charset=UTF-8");
			response.getWriter().print(account);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	
	/**
	 * 
	 * <p>Description: 爱旺旺2.0传回来的连接然后跳转到1.0的ear登入模块</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00306219
	 * @date 2017年7月6日 下午3:01:19
	 * @param request
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("PM")
	public ModelAndView hrPM(HttpServletRequest request) throws Throwable {
		//绩效考核
		String getUrl = "http://hrqas.want-want.com:52000/irj/portal/PM2";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	//薪资单查询
	@RequestMapping("XZDCX")
	public ModelAndView hrXZDCX(HttpServletRequest request) throws Throwable {
		//薪资单查询
		String getUrl = "http://hrqas.want-want.com:52000/irj/portal/XZDCX";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	//员工培训
	@RequestMapping("ISO")
	public ModelAndView hrISO(HttpServletRequest request) throws Throwable {
		// 员工培训
		String getUrl = "http://hrqas.want-want.com:52000/irj/portal/ISO";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	//人才旺
	@RequestMapping("Talent")
	public ModelAndView hrTalent(HttpServletRequest request) throws Throwable {
		//人才旺
		String getUrl = "http://10.0.1.230:50400/talentwant/home/checkLoginTalent";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	//员工照片维护
	@RequestMapping("EmpPhotoUpdate")
	public ModelAndView empPhotoUpdate(HttpServletRequest request) throws Throwable {
		//员工照片维护
		String getUrl = "http://nwcep73:50600/webdynpro/resources/com.want/stand~empimage~wd/EmpImageApp";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	//满意度交叉考评
	@RequestMapping("Fusa")
	public ModelAndView fusa(HttpServletRequest request) throws Throwable {
		// 满意度交叉考评
		String getUrl = "http://nwcep73:50600/fusa/index";
		String resUrl = this.mosaicUrl(getUrl, request);
		return new ModelAndView(new RedirectView(resUrl));
	}
	
	public String mosaicUrl(String url,HttpServletRequest request) throws Throwable{
		String vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(url);
		strBuffer.append("?vt=");
		strBuffer.append(vt);
		return strBuffer.toString();
	}
	
	
	
	/**
	 * 通过vt获取当前登录用户信息
	 * @author 00319159
	 * 下午3:59:44
	 * @param vt
	 * @return
	 *  旺旺集团
	 * @throws UnsupportedEncodingException 
	 */
	public  SsoUser getUserByVt(HttpServletRequest request,String backUrl) throws Exception{
		ModelAndView mv = new ModelAndView();
		String vt = "";
		try {
			vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		} catch (Exception e1) {
			LOGGER.error("获取cookie vt失败{}", ExceptionUtil.getTrace(e1));
		}
		SsoUser ssoUser = null;
		/* vt存在 */
		if (StringUtils.isNotEmpty(vt)) {
			// 从redis里面取出来realVt（vt)
			byte[] byteSsoUser = redisService.get(vt);

			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({})获取用户信息成功!", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				try {
					ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
				} catch (IOException e) {
					e.printStackTrace();
					/* 登录过期，转入登录页面 */
					LOGGER.error("获取redis内用户失败vt({}) check false !", vt);
					this.validateFailed(backUrl, mv);
				}
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({})获取用户失败!", vt);
				this.validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			this.validateFailed(backUrl, mv);
		}
		return ssoUser;
	}
	
	
	/**
	 * 通过传过来的vt获取当前登录用户信息
	 * @author 00319159
	 * 下午3:59:44
	 * @param vt
	 * @return
	 *  旺旺集团
	 * @throws UnsupportedEncodingException 
	 */
	public  SsoUser getUserByVtUseVt(HttpServletRequest request,String backUrl,String vt) throws Exception{
		ModelAndView mv = new ModelAndView();
		SsoUser ssoUser = null;
		/* vt存在 */
		if (StringUtils.isNotEmpty(vt)) {
			// 从redis里面取出来realVt（vt)
			byte[] byteSsoUser = redisService.get(vt);

			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({})获取用户信息成功!", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				try {
					ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
				} catch (IOException e) {
					e.printStackTrace();
					/* 登录过期，转入登录页面 */
					LOGGER.error("获取redis内用户失败vt({}) check false !", vt);
					this.validateFailed(backUrl, mv);
				}
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({})获取用户失败!", vt);
				this.validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			this.validateFailed(backUrl, mv);
		}
		return ssoUser;
	}
	
	/**
	 * <验证失败时，判断是否重新登录的操作>
	 * 
	 * @param backUrl
	 * @param mv
	 */
	public  void validateFailed(String backUrl, ModelAndView mv) {
		if (StringUtils.isNoneEmpty(backUrl)) {
			mv.addObject("backUrl", backUrl);
		}
		// 转到登录页面
		mv.setViewName(loginConfig.getLoginViewName());
	}

	
	/**
	 * <vt验证失败，生成vt，按需添加lt>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @param ssoUser
	 * @param rememberMe
	 * @param mv
	 * @throws Exception
	 */
	public  void validateSucceed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			String backUrl, SsoUser ssoUser, boolean rememberMe, ModelAndView mv) throws Exception {

		// 先将密码置空
		//ssoUser.setPassword("********");
		if (rememberMe) {
			/* rememberMe=true时，表示lt已失效 */
			// 重新生成lt
			String lt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
			// 添加ltcookie
			CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName(), lt, true);
			// 添加用户到redis
			redisService.set(lt, MAPPER.writeValueAsString(ssoUser), loginConfig.getLtRedisMaxTime());
			LOGGER.info("remember me new lt={}", lt);
		}
		// 生成vt
		String vt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		// 添加vtcookie
		CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName(), vt, true);
		// 添加vt用户到redis
		redisService.set(vt, MAPPER.writeValueAsString(ssoUser), loginConfig.getVtRedisMaxTime());
		LOGGER.info("new vt={}", vt);
		if (StringUtils.isNotEmpty(backUrl)) {
			mv.setViewName("redirect:" + backUrl);
		} else {
			mv.setViewName("redirect:" + loginConfig.getPortalUrl());
		}

	}
	

	/**
	 * 生成16位随机字符串
	 * @author 00319159
	 * 下午4:33:28
	 * @return
	 *  旺旺集团
	 */
	public  String keyStrUtil(){
       String string = "qwertyuiopasdfghjklzxcvbnmQAZWSXEDCRFVTGBYHNUJMIKOLP";
       StringBuffer sb = new StringBuffer();
       int len = string.length();
       for (int i=0; i<16; i++) {
           sb.append(string.charAt((int)Math.round(Math.random()*(len-1))));
       }
       String keyStr = sb.toString();
       return keyStr;
	}
	
}

