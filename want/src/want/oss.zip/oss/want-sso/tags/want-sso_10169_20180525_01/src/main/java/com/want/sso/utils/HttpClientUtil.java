package com.want.sso.utils;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * <p>Title:工具类 </p>
 * <p>Description:http请求工具，可以根据实际情况不断丰富方法</p>
 * <p>Company:旺旺集团</p>
 * @author 00301082
 * @date 2018年4月25日 上午10:43:05
 */
public class HttpClientUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientUtil.class);
	/**
	 * 
	 * <p>Description:带参数的Get请求 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月25日 上午10:42:51
	 * @param url
	 * @param param
	 * @return
	 */
    public static String doGet(String url, Map<String, String> param) {
        // 创建Httpclient对象
        CloseableHttpClient httpclient = HttpClients.createDefault();
        String resultString = "";
        CloseableHttpResponse response = null;
        try {
            // 创建uri
            URIBuilder builder = new URIBuilder(url);
            if (param != null) {
                for (String key : param.keySet()) {
                    builder.addParameter(key, param.get(key));
                }
            }
            URI uri = builder.build();
            // 创建http GET请求
            HttpGet httpGet = new HttpGet(uri);
            // 执行请求
            response = httpclient.execute(httpGet);
            // 判断返回状态是否为200
            if (response.getStatusLine().getStatusCode() == 200) {
                resultString = EntityUtils.toString(response.getEntity(), "UTF-8");
            }
        } catch (Exception e) {
        	LOGGER.error("发送的GET请求出现异常，路径是：{" + url+"},异常信息"+e.getMessage());
        } finally {
            try {
                if (response != null) {
                    response.close();
                }
                httpclient.close();
            } catch (IOException e) {
            	LOGGER.error("发送的GET请求出现异常，路径是：{" + url+"},异常信息"+e.getMessage());
                e.printStackTrace();
            }
        }
        return resultString;
    }

    /**
     * 
     * <p>Description:POST请求 </p>
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月26日 下午2:14:01
     * @param url
     * @param map
     * @param charset
     * @return
     */
    public static String doPost(String url, Map<String,String> map, String charset){
        CloseableHttpClient httpClient = null;
        HttpPost httpPost = null;
        String result = null;
        try{
            httpClient = HttpClients.createDefault();
            httpPost = new HttpPost(url);
            
            //装填请求参数
            List<NameValuePair> list = new ArrayList<NameValuePair>();
            for (Map.Entry<String, String> entry : map.entrySet()) {
                    list.add(new BasicNameValuePair(entry.getKey(),entry.getValue()));
            }
            //设置参数到请求对象中
            httpPost.setEntity(new UrlEncodedFormEntity(list,charset));
            
            HttpResponse response = httpClient.execute(httpPost);
            
            if(response != null){
                HttpEntity resEntity = response.getEntity();
                if(resEntity != null){
                    result = EntityUtils.toString(resEntity,charset);
                }
            }
        }catch(Exception e){
        	LOGGER.error("发送的POST请求出现异常，路径是：{" + url+"},异常信息"+e.getMessage());
        }
        return result;
    }
    
    /**
     * 
     * <p>Description: 没有带参数的GET请求</p>
     * <p>Company:want-want </p>
     * @author 00301082
     * @date 2018年4月25日 上午10:44:29
     * @param url
     * @return
     */
    public static String doGet(String url) {
        return doGet(url, null);
    }

}
