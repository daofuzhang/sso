/*
 * -------------------------------------------------------
 * @FileName SysIntegtateController.java
 * @Description 系统集成
 * @Author 00319159
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.crystaldecisions.sdk.occa.security.ILogonTokenMgr;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.common.pojo.SsoUser;
import com.want.common.service.RedisService;
import com.want.common.util.CookieUtil;
import com.want.common.util.ExceptionUtil;
import com.want.sso.pojo.LoginConfig;
import com.want.sso.utils.CryptAES;

@Controller
@RequestMapping(value = "integration")
public class SysIntegrateController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
	
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	@Value(value = "${discussUrl}")
    private String discussUrl;
	
	@Value(value = "${cms}")
	private  String cms;
	
	@Value(value = "${boUrl}")
	private String boUrl;
	
	@Autowired
	private LoginConfig loginConfig;

	@Autowired
	private RedisService redisService;

	/**
	 * nw系统集成
	 * @author 00319159
	 * @param httpServletRequest
	 * @param vt
	 * @return IntegrationPojo
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value = "validate_service", method = RequestMethod.GET)
	public @ResponseBody String systemIntegration(HttpServletRequest request) throws UnsupportedEncodingException {
		ModelAndView mv =  new ModelAndView();
		String account = "";
		String backUrl = "";
		SsoUser ssoUser = null;
		try {
			ssoUser = this.getUserByVt(request, backUrl);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(ssoUser==null){
			this.validateFailed(backUrl, mv);
       	}else{
       		account = ssoUser.getAccount();
			LOGGER.info("account({}) 用户工号!", account);
       	}
		return account;
	}
	

	
	
	/**
	 * 讨论区集成
	 * @author 00319159
	 * 下午4:35:40
	 * @param response
	 * @param vt
	 * @return 
	 * @throws Exception
	 *  旺旺集团
	 */
	@RequestMapping(value="discuss")
    public ModelAndView discussLogin(HttpServletResponse response,HttpServletRequest request) throws Exception{
		
		ModelAndView mv = new ModelAndView();
		String backUrl = "";
		 // 获取当前登录人员信息
        SsoUser ssoUser = this.getUserByVt(request,backUrl);
    	if(ssoUser==null){
       		this.validateFailed(backUrl, mv);
       	}else{
			String plainText = ssoUser.getAccount();
			LOGGER.info("account({}) 用户工号!", plainText);
			//生成16位随机字符串
			String keyStr = this.keyStrUtil();
			LOGGER.info("生成16位随机字符串({})", keyStr);
			//加密工号
			String encUserCode = CryptAES.AES_Encrypt(keyStr, plainText);
			LOGGER.info("加密工号({}) ", encUserCode);
			
			//设置cookie
			Cookie cookie = new Cookie("encUserCode", URLEncoder.encode(encUserCode, "UTF-8"));
			cookie.setDomain("want-want.com");
			cookie.setPath("/");
	        response.addCookie(cookie);
	        
	        mv = new ModelAndView("redirect:"+discussUrl+keyStr);
       	}
        return mv;
    }
	

	
	


	/**
	  * 登录bo 获取Token
	  * @author 00319159
	  * 下午1:24:41
	  * @param vt
	  * @param request
	  * @return
	  *  旺旺集团
	  */
   @RequestMapping(value = "bo/getToken", method = RequestMethod.GET)
   public  ModelAndView boGetToken(HttpServletRequest request,
		   @RequestParam(value = "sIDType",required = true) String sIDType) throws Exception{
	   
	   LOGGER.info("传过来的sIDType为({}) ", sIDType);
	   
	   ModelAndView mv = null;
	   ISessionMgr sessionMgr = null;
       String defaultToken = null;
       String backUrl = null;
       try {
       	SsoUser ssoUser = this.getUserByVt(request,backUrl);
       	if(ssoUser!=null){
       		LOGGER.info("查看bo的emp", ssoUser.toString());
			       	String account = ssoUser.getAccount();
			           byte[] serializedSession = redisService.get(account + "bo");
			           //判断redis中的session是否存在
			           if (serializedSession == null || serializedSession.length == 0) {
			               // CMS服务器名，也可以是IP地址
			              // String cms = "10.0.1.237:6400";
			               String authentication = "secLDAP";
			               String password = ssoUser.getPassword();// 密码
			               String aes_Decrypt = CryptAES.AES_Decrypt("1234567890123456", password);
			               sessionMgr = CrystalEnterprise.getSessionMgr();
			               //将新的session存储在redis中
			               IEnterpriseSession enterpriseSession = sessionMgr.logon(account, aes_Decrypt, cms,authentication);
			               String serializedSessionNew = enterpriseSession.getSerializedSession();
			               redisService.set(account + "bo", serializedSessionNew,60*10);
			               //获取token
			               IEnterpriseSession session = sessionMgr.getSession(serializedSessionNew);
			               ILogonTokenMgr logonTokenMgr = session.getLogonTokenMgr();
			               defaultToken = logonTokenMgr.getDefaultToken();
			               LOGGER.info("serializedSession为空 默认的token({}) ", defaultToken);
			           } else {
			           	//获取token
			        	   sessionMgr = CrystalEnterprise.getSessionMgr();
			               IEnterpriseSession session = sessionMgr.getSession(new String(serializedSession));
			               ILogonTokenMgr logonTokenMgr = session.getLogonTokenMgr();
			               defaultToken = logonTokenMgr.getDefaultToken();
			               LOGGER.info("serializedSession不为空  默认的token({}) ", defaultToken);
			           }
			           String redirectUrl = "redirect:"+boUrl+sIDType+"&token="+defaultToken;
			           LOGGER.info("bo跳转成功的empId为({}) ", ssoUser.toString()); 
			           LOGGER.info("重定向地址为({}) ", redirectUrl); 
			          mv = new ModelAndView(redirectUrl);
			          
		       	}else{
		       		this.validateFailed(backUrl, mv);
		       	}
	       } catch (Exception e) {
	       	LOGGER.error(ExceptionUtil.getTrace(e));
	       }
      
       return mv;
   }


	/**
	 * <验证失败时，判断是否重新登录的操作>
	 * 
	 * @param backUrl
	 * @param mv
	 */
	public  void validateFailed(String backUrl, ModelAndView mv) {
		 LOGGER.info("验证失败  "+backUrl); 
		if (StringUtils.isNoneEmpty(backUrl)) {
			mv.addObject("backUrl", backUrl);
		}
		// 转到登录页面
		mv.setViewName(loginConfig.getLoginViewName());
	}

	
	
	/**
	 * 生成16位随机字符串
	 * @author 00319159
	 * 下午4:33:28
	 * @return
	 *  旺旺集团
	 */
	public  String keyStrUtil(){
       String string = "qwertyuiopasdfghjklzxcvbnmQAZWSXEDCRFVTGBYHNUJMIKOLP";
       StringBuffer sb = new StringBuffer();
       int len = string.length();
       for (int i=0; i<16; i++) {
           sb.append(string.charAt((int)Math.round(Math.random()*(len-1))));
       }
       String keyStr = sb.toString();
       return keyStr;
	}
	
	/**
	 * 通过vt获取当前登录用户信息
	 * @author 00319159
	 * 下午3:59:44
	 * @param vt
	 * @return
	 *  旺旺集团
	 * @throws UnsupportedEncodingException 
	 */
	public  SsoUser getUserByVt(HttpServletRequest request,String backUrl) throws Exception{
		ModelAndView mv = new ModelAndView();
		String vt = "";
		try {
			vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		} catch (Exception e1) {
			LOGGER.error("获取cookie vt失败{}", ExceptionUtil.getTrace(e1));
		}
		SsoUser ssoUser = null;
		/* vt存在 */
		if (StringUtils.isNotEmpty(vt)) {
			// 从redis里面取出来realVt（vt)
			byte[] byteSsoUser = redisService.get(vt);

			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({})获取用户信息成功!", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				try {
					ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
				} catch (IOException e) {
					e.printStackTrace();
					/* 登录过期，转入登录页面 */
					LOGGER.error("获取redis内用户失败vt({}) check false !", vt);
					this.validateFailed(backUrl, mv);
				}
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({})获取用户失败!", vt);
				this.validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			this.validateFailed(backUrl, mv);
		}
		return ssoUser;
	}

}
