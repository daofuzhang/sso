package com.want.sso.pojo;
/**
 * 
 * <p>Title:实体类 </p>
 * <p>Description:第三方系统用户</p>
 * <p>Company:旺旺集团</p>
 * @author 00301082
 * @date 2018年4月12日 上午9:55:18
 */
public class GhostUser {

	private String key;//系统互信key
	
	private String userId; //工号
	
	private String url; //跳转到爱旺旺的URL

	private String vt; //第三方系统传入的互信值（可以为空，加这个是为了want2.0和icustomer2.0都能和SEP系统互信）
	
	private String signId; //第三系统在系统中注册的互信URL的签名，不能为空，便于系统向第三方系统发送请求
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getVt() {
		return vt;
	}

	public void setVt(String vt) {
		this.vt = vt;
	}

	public String getSignId() {
		return signId;
	}

	public void setSignId(String signId) {
		this.signId = signId;
	}

	@Override
	public String toString() {
		return "GhostUser [key=" + key + ", userId=" + userId + ", url=" + url + ", vt=" + vt + ", signId=" + signId
				+ "]";
	}

}
