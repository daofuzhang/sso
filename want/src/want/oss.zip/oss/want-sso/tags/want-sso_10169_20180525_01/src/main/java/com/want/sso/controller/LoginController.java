/*
 * -------------------------------------------------------
 * @FileName LoginController.java
 * @Description 用户登录登出相关方法
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.common.pojo.SsoUser;
import com.want.common.service.RedisService;
import com.want.common.util.CookieUtil;
import com.want.common.util.ExceptionUtil;
import com.want.sso.pojo.GhostUser;
import com.want.sso.pojo.LoginConfig;
import com.want.sso.pojo.User;
import com.want.sso.pojo.WantWebServiceData;
import com.want.sso.service.ILdapService;
import com.want.sso.utils.CryptAES;
import com.want.sso.utils.CustomerUtil;
import com.want.sso.utils.DesUtils;
import com.want.sso.utils.HttpClientUtil;
import com.want.sso.utils.WantDes4Sso;

/**
 * @description 登录的controller
 * @author 00294476
 * @version V1.0.0
 */
@Controller
public class LoginController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	private static final ObjectMapper MAPPER = new ObjectMapper();

	@Autowired
	private LoginConfig loginConfig;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ILdapService ldapService;

	@Value(value = "${innerSepSystemUrl}")
	private String innerSepSystemUrl;
	
	@Value(value = "${outerSepSystemUrl}")
	private String outerSepSystemUrl;

	@Value(value = "${ghostSsoGetKeyUrl}")
	private String getKeyUrl;
	
	@Value(value = "${get.customer.mgmt.des.key}")
	private String iCustomerLoginDesKey;//登入sso到经销商DES解密的key
	
	@Value(value = "${icustomer.login.url}")
	private String iCustomerLoginUrl;//经销商登入入口
	
	@Value(value = "${icustomer.ghost.login.url}")
	private String iCustomerLoginGhostUrl;//经销商第三方系统登入入口
	
	@Value(value = "${want.to.icustomer_sign.id}")
	private String want2IcustomerSignId;//登入经销商网站的签名，在经销商网站数据库注册一个签名
	
	@Value(value = "${ghost.to.want2.geturl.sign}")
	private String ghost2WantSignId;//其他系统登入到爱旺旺需要注册URL的signId
	
	/**
	 * <登录方法，给二级系统做logincheck>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam(value = "backUrl", required = false) String backUrl) {

		ModelAndView mv = new ModelAndView();
		
		String vt = "";
		try {
			vt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getVtCookieName(), true);
		} catch (UnsupportedEncodingException e1) {
			LOGGER.error("获取cookie vt失败{}", ExceptionUtil.getTrace(e1));
		}
		if (StringUtils.isNotEmpty(vt)) {
			/* vt存在 */
			// 从redis里面取出来vt user
			byte[] byteSsoUser = redisService.get(vt);
			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({}) check success !", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());
				
				/*
				 * *********************** 临时添加icustomer验证， 当判读是经销商的时候，跳转到SEP，
				 * 等icustomer2.0网站完成后，注释这段代码
				 * 
				 * 00294476
				 */
				try {
					SsoUser ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
					boolean flag = ldapService.isCustomer(ssoUser.getAccount());
					if (flag) {
						String ipAddress = getIpAddress(httpServletRequest);
						LOGGER.info("enter ipAddress:{}", ipAddress);
						if (isInnerIp(ipAddress)) {
							CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
							mv.setViewName("redirect:" + innerSepSystemUrl);
						} else {
							CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
							mv.setViewName("redirect:" + outerSepSystemUrl);
						}
					} else {
						mv.setViewName("redirect:" + loginConfig.getPortalUrl());
					}
				} catch (Exception e) {
					LOGGER.error(ExceptionUtil.getTrace(e));
				}
				
				
				// mv.setViewName("redirect:" +
				// loginConfig.getPortalUrl());//等icustomer2.0网站完成后，释放这段代码
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({}) check false !", vt);
				validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			String lt = "";
			try {
				lt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getLtCookieName(), true);
			} catch (UnsupportedEncodingException e1) {
				LOGGER.error("获取cookie lt失败{}", ExceptionUtil.getTrace(e1));
			}
			if (StringUtils.isNotEmpty(lt)) {
				/* lt存在 */
				// 从redis里面取出来lt user
				byte[] byteSsoUser = redisService.get(lt);
				if (byteSsoUser != null) {
					LOGGER.info("当前的lt({})用户从redis中获取成功", lt);
					/* lt验证成功 */
					try {
						SsoUser ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
						validateSucceed(httpServletRequest, httpServletResponse, backUrl, ssoUser, false, mv);
					} catch (Exception e) {
						LOGGER.error(ExceptionUtil.getTrace(e));
					}
				} else {
					/* redis里面没有lt用户 */
					LOGGER.info("当前的lt({})用户从redis中获取失败", lt);
					validateFailed(backUrl, mv);
				}
			} else {
				/* lt也不存在，表示没有remember me */
				// 执行validateFailed
				validateFailed(backUrl, mv);
			}
		}
		return mv;
	}
	
	/**
	 * 
	 * <p>Description:第三方系统集成爱旺旺入口 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月12日 下午3:35:04
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @param key
	 * @return
	 */
	@RequestMapping(value = "login_ghost", method = RequestMethod.GET)
	public ModelAndView loginGhost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam(value = "backUrl", required = false) String backUrl,
			@RequestParam(value = "key", required = false) String key) {
		
		ModelAndView mv = new ModelAndView();
		
		//添加代码便于第三方系统可以登入爱旺旺2.0
		try {
			//1.解密为json
			String vtJson = getJsonDataBySecretKey(key);
			if (StringUtils.isNoneBlank(vtJson)) {
				ObjectMapper mapper = new ObjectMapper();
				GhostUser ghostUser = mapper.readValue(vtJson, GhostUser.class);
				//2.1.校验JSON中的key
				Map<String, String> param = new HashMap<String, String>();
				String doPostResutl = null;
				param.put("signId", ghostUser.getSignId());
				try {
					
					doPostResutl = HttpClientUtil.doPost(ghost2WantSignId, param, "UTF-8");
				} catch (Exception e) {
					LOGGER.error("爱旺旺2.0通过签名去获取第三方集成认证的URL出现异常，接口是 ："+ghost2WantSignId+",异常信息是：{"+e.getMessage()+"}");
					ghostUser.setUserId(null);
					validateFailed(backUrl, mv);
				}
				
				if (StringUtils.isNoneBlank(doPostResutl)) {
					//解析返回的结果，将data中认证URL取出来
					WantWebServiceData wantWsData = mapper.readValue(doPostResutl, WantWebServiceData.class);
					if (wantWsData != null) {
						if (StringUtils.isNoneBlank(wantWsData.getData())) {
							String doGet = "";
							try {
								 //请求第三方系统,返回数据格式 {"data":"00301082","status":true}
								doGet = HttpClientUtil.doGet(wantWsData.getData());
								if (StringUtils.isNoneBlank(doGet)) {
									WantWebServiceData doGetResult = mapper.readValue(doGet, WantWebServiceData.class);
									if (doGetResult != null) {
										if (StringUtils.isNoneBlank(doGetResult.getData())) {
											
											LOGGER.info("爱旺旺2.0返回通过获取到第三方校验token的URL，获取ID成功。接口是:"+wantWsData.getData());
											ghostUser.setUserId(doGetResult.getData());
										} else {

											LOGGER.error("爱旺旺2.0返回通过获取到第三方校验token的URL，返回数据为空。接口是:"+wantWsData.getData());
											ghostUser.setUserId(null);
											validateFailed(backUrl, mv);
										}
									}else{
										
										LOGGER.error("爱旺旺2.0返回通过获取到第三方校验token的URL，解析出来的json为空。接口是:"+wantWsData.getData());
										ghostUser.setUserId(null);
										validateFailed(backUrl, mv);
									}
								}else{
									
									LOGGER.error("爱旺旺2.0返回通过获取到第三方校验token的URL，返回数据为空。接口是:"+wantWsData.getData());
									ghostUser.setUserId(null);
									validateFailed(backUrl, mv);
								}
							} catch (Exception e) {
								
								LOGGER.error("爱旺旺2.0返回通过获取到第三方校验token的URL，返回验证发送GET请求的时候出现异常。接口是:"+wantWsData.getData());
								ghostUser.setUserId(null);
								validateFailed(backUrl, mv);
							}
							
						}else{
							
							LOGGER.error("爱旺旺2.0通过签名去获取第三方集成认证的URL,解析出来的数据为空，本来的数据应该是个URL，接口是："+ghost2WantSignId);
							ghostUser.setUserId(null);
							validateFailed(backUrl, mv);
						}
					}else{
						
						LOGGER.error("爱旺旺2.0通过签名去获取第三方集成认证的URL为空或请求接口出现异常，请求接口是："+ghost2WantSignId);
						ghostUser.setUserId(null);
						validateFailed(backUrl, mv);
					}
				} else {

					LOGGER.error("爱旺旺2.0通过签名去获取第三方集成认证的URL为空，请求接口是："+ghost2WantSignId);
					ghostUser.setUserId(null);
					validateFailed(backUrl, mv);
				}
				
				//校验工号是否存在
				if (StringUtils.isNoneBlank(ghostUser.getUserId())) {
					User userInfo = ldapService.getUserInfo(ghostUser.getUserId());
					if (userInfo != null) {
						if (StringUtils.isNoneBlank(userInfo.getUserId())) {//校验成功
							
							SsoUser user = new SsoUser();
							user.setAccount(ghostUser.getUserId());
							user.setPassword("*********");;
							backUrl = ghostUser.getUrl();
							mv = validateSucceedGhost(httpServletRequest, httpServletResponse, backUrl, user);
						}else{
							
							validateFailed(backUrl, mv);
						}
					}else{
						
						validateFailed(backUrl, mv);
					}
				}else {
					
					validateFailed(backUrl, mv);
				}
			}else{
				
				validateFailed(backUrl, mv);
			}
		} catch (Exception e) {
			LOGGER.error("第三方系统集成登入爱旺旺出现异常");
			validateFailed(backUrl, mv);
			e.printStackTrace();
		}
		
		return mv;
	}
	

	/**
	 * <页面登录>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param user
	 * @param backUrl
	 * @param rememberMe
	 * @param vt 第三方系统集成爱旺旺携带的参数，格式是json加密后的字符串
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView login(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			SsoUser user, @RequestParam(value = "backUrl", required = false) String backUrl,
			@RequestParam(value = "rememberMe", required = false) boolean rememberMe) {

		ModelAndView mv = new ModelAndView();
		LOGGER.info("start login username={}", user.getAccount());
		try {
			boolean isLogon = ldapService.loginAD(user.getAccount(), user.getPassword());
			if (isLogon) {
				LOGGER.info("login success !");
				/* ad验证成功 */
				validateSucceed(httpServletRequest, httpServletResponse, backUrl, user, rememberMe, mv);
			} else {
				validateFailed(backUrl, mv);
				// mv.addObject("error", "用户名或者密码不正确");
				mv.addObject("error", "密码输入错误三次，帐号将被锁");
			}
		} catch (Exception e) {
			validateFailed(backUrl, mv);
			mv.addObject("error", "服务器内部错误");
			LOGGER.error(ExceptionUtil.getTrace(e));
		}
		return mv;
	}

	/**
	 * <验证失败时，判断是否重新登录的操作>
	 * 
	 * @param backUrl
	 * @param mv
	 */
	private void validateFailed(String backUrl, ModelAndView mv) {
		if (StringUtils.isNoneEmpty(backUrl)) {
			mv.addObject("backUrl", backUrl);
		}
		// 转到登录页面
		mv.setViewName(loginConfig.getLoginViewName());
	}

	/**
	 * <vt验证失败，生成vt，按需添加lt>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @param ssoUser
	 * @param rememberMe
	 * @param mv
	 * @throws Exception
	 */
	private void validateSucceed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			String backUrl, SsoUser ssoUser, boolean rememberMe, ModelAndView mv) throws Exception {

		// 加密工号--00319159  2017年12月18日14:47:09
		String password = ssoUser.getPassword();
		if (StringUtils.isNoneBlank(password)) {
			
			String aes_Encrypt = CryptAES.AES_Encrypt("1234567890123456", password);
			ssoUser.setPassword(aes_Encrypt);
		}
		
		if (rememberMe) {
			/* rememberMe=true时，表示lt已失效 */
			// 重新生成lt
			String lt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
			// 添加ltcookie
			CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName(), lt, true);
			// 添加用户到redis
			redisService.set(lt, MAPPER.writeValueAsString(ssoUser), loginConfig.getLtRedisMaxTime());
			LOGGER.info("remember me new lt={}", lt);
		}
		// 生成vt
		String vt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		// 添加vtcookie
		CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName(), vt, true);
		// 添加vt用户到redis
		redisService.set(vt, MAPPER.writeValueAsString(ssoUser), loginConfig.getVtRedisMaxTime());
		LOGGER.info("new vt={}", vt);
		/*
		 * ************************ 临时添加icustomer验证， 当判读是经销商的时候，跳转到SEP，
		 * 等icustomer2.0网站完成后，注释这段代码
		 * 
		 * 00294476
		 */
		boolean flag = ldapService.isCustomer(ssoUser.getAccount());
		if (flag) {

			String ipAddress = getIpAddress(httpServletRequest);
			LOGGER.info("enter ipAddress:{}", ipAddress);
			if (isInnerIp(ipAddress)) {
				mv.setViewName("redirect:" + innerSepSystemUrl);
			} else {
				mv.setViewName("redirect:" + outerSepSystemUrl);
			}

		} else if (StringUtils.isNotEmpty(backUrl)) {
			mv.setViewName("redirect:" + backUrl);
		} else {
			mv.setViewName("redirect:" + loginConfig.getPortalUrl());
		}

		//集成登入到新的经销商网站 TODO 新经销商网站正式上线之后需要启动一下代码
//		boolean flag = ldapService.isCustomer(ssoUser.getAccount());
//		if (flag) {
//			
//			try {
//				//获取加密key
//				String key = this.getIcustomerSsoKey(iCustomerLoginDesKey);
//				if (StringUtils.isNoneBlank(key)) {
//					//拼接请求的JSON
//					String icustomerJson = CustomerUtil.makeIcustomerJson(vt, "",want2IcustomerSignId);
//					String icustomerJsonDes = WantDes4Sso.DES_CBC_Encrypt(icustomerJson, key);
//					if (StringUtils.isNoneBlank(icustomerJsonDes)) {
//						mv.setViewName("redirect:" + iCustomerLoginGhostUrl + URLEncoder.encode(icustomerJsonDes, "UTF-8"));
//						LOGGER.info("爱旺旺开始跳转到新的经销商网站");
//						
//					} else {
//						
//						mv.setViewName("redirect:" + iCustomerLoginUrl);
//						LOGGER.error("爱旺旺2.0登入到经销商网站，拼接的JSON为空");
//					}
//				}else{
//					
//					//若到经销商的mgmt模块获取加密的key为空则返回到经销商模块
//					LOGGER.error("爱旺旺2.0登入到经销商网站，获取DES加密的key为空");
//					mv.setViewName("redirect:" + iCustomerLoginUrl);
//				}
//				
//			} catch (Exception e) {
//				e.printStackTrace();
//				LOGGER.error("爱旺旺2.0登入到经销商网站，出现异常");
//				mv.setViewName("redirect:" + iCustomerLoginUrl);
//			}
//		} else if (StringUtils.isNotEmpty(backUrl)) {
//			mv.setViewName("redirect:" + backUrl);
//		} else {
//			mv.setViewName("redirect:" + loginConfig.getPortalUrl());
//		}
		/*
		 * 等icustomer2.0网站完成后，释放这段代码 00294476 if (StringUtils.isNotEmpty(backUrl)) {
		 * mv.setViewName("redirect:" + backUrl); } else { mv.setViewName("redirect:" +
		 * loginConfig.getPortalUrl()); }
		 */

	}
	
	/**
	 * 
	 * <p>Description:获取登入到经销DES解密的Key </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月23日 下午4:12:12
	 * @param keyUrl
	 * @return
	 */
	private String getIcustomerSsoKey(String keyUrl) {
		
		String jsonKey="";
		try {
		    URL realUrl;
		    HttpURLConnection conn = null;
		    BufferedReader bufferedReader = null;
			
			if (StringUtils.isNoneBlank(keyUrl)) {
				
				realUrl = new URL(keyUrl);
				conn = (HttpURLConnection) realUrl.openConnection();
				
				bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line;
				if ((line = bufferedReader.readLine()) != null) {
					jsonKey += line;
				}
			}
			
			ObjectMapper mapper = new ObjectMapper();
			WantWebServiceData wantWsData = mapper.readValue(jsonKey, WantWebServiceData.class);
			
			if (StringUtils.isNoneBlank(wantWsData.getData())) {
				jsonKey = wantWsData.getData();
				if (StringUtils.isNoneBlank(jsonKey)) {
					//解密key（数据库数据加密的key）
					DesUtils des = new DesUtils("ThisIsSecret");
					jsonKey = des.decrypt(jsonKey);
				}else{
					jsonKey="";
				}
			}else{
				jsonKey = "";
			}
			return jsonKey;
			
		} catch (Exception e) {

			e.printStackTrace();
			return jsonKey;
		}
	}

	private ModelAndView validateSucceedGhost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			String backUrl, SsoUser ssoUser) throws Exception {
		
		// 生成vt
		String vt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		// 添加vtcookie
		CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName(), vt, true);
		// 添加vt用户到redis
		redisService.set(vt, MAPPER.writeValueAsString(ssoUser), loginConfig.getVtRedisMaxTime());
		LOGGER.info("new vt={}", vt);
		if (StringUtils.isNoneBlank(backUrl)) {
			
			return new ModelAndView(new RedirectView(backUrl));
		}else{
			return new ModelAndView(new RedirectView(loginConfig.getPortalUrl()));
		}
	}

	/**
	 * <登出>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @throws Exception
	 * @throws ClientProtocolException
	 */
	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		String vt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getVtCookieName(), true);
		if (StringUtils.isNotEmpty(vt)) {
			// 删除cookie(vt)
			CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
			// 删除redis中的登录的用户
			redisService.delete(vt);
			String lt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getLtCookieName(), true);
			if (StringUtils.isNotEmpty(lt)) {
				// 删除cookie(lt)
				CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName());
				// 删除redis中的免登陆用户
				redisService.delete(lt);
			}
		}
		LOGGER.info("logout success vt={}", vt);
		mv.setViewName(loginConfig.getLoginViewName());
		return mv;
	}

	/**
	 * 
	 * <p>Description:新的经销商网站和爱旺旺2.0共用vt便于两个系统和其他系统SSO </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月26日 上午10:51:03
	 * @param vt
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "cus_want_cookie", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> setCusAndWantSameCookieVt(String vt, String id, String vtRedisMaxTime){
		Map<String, Object> map = new HashMap<>();
		try {
			if (StringUtils.isNoneBlank(vt) && StringUtils.isNoneBlank(id)) {
				
				SsoUser ssoUser = new SsoUser();
				ssoUser.setAccount(id);
				ssoUser.setPassword("*********");
				// 添加vt用户到redis
				redisService.set(vt, MAPPER.writeValueAsString(ssoUser), Integer.parseInt(vtRedisMaxTime));
				map.put("data", vt);
				map.put("status", true);
			}else{
				
				map.put("data", "");
				map.put("status", true);
			}
		} catch (Exception e) {
			
			map.put("data", "");
			map.put("status", false);
			e.printStackTrace();
		}
		return map;
	}
	
	/**
	 * 
	 * <p>Description:新的经销商网站和爱旺旺2.0共用vt设置redis生效时间 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月26日 上午11:11:25
	 * @param vt
	 * @param vtRedisMaxTime
	 * @return
	 */
	@RequestMapping(value = "cus_want_vt_time", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> setVtRedisMaxTime(String vt, String vtRedisMaxTime){
		Map<String, Object> map = new HashMap<>();
		try {
			if (StringUtils.isNoneBlank(vt)) {
				
				redisService.expire(vt, Integer.parseInt(vtRedisMaxTime));
				map.put("data", vt);
				map.put("status", true);
			}else{
				
				map.put("data", "");
				map.put("status", true);
			}
		} catch (Exception e) {
			
			map.put("data", "");
			map.put("status", false);
			e.printStackTrace();
		}
		return map;
	}
	
	/**
	 * 
	 * <p>Description:删除经销商存在want2.0共用的vt </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月26日 下午4:41:38
	 * @param vt
	 * @return
	 */
	@RequestMapping(value = "del_want_vt", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> delCusAndWantSameCookieVt(String vt){
		Map<String, Object> map = new HashMap<>();
		try {
			if (StringUtils.isNoneBlank(vt)) {
				
				redisService.delete(vt);
				map.put("data", vt);
				map.put("status", true);
			}else{
				
				map.put("data", "");
				map.put("status", true);
			}
		} catch (Exception e) {
			
			map.put("data", "");
			map.put("status", false);
			e.printStackTrace();
		}
		return map;
	}
	
	/**
	 * 获取用户真实IP地址，不使用request.getRemoteAddr();的原因是有可能用户使用了代理软件方式避免真实IP地址
	 * 
	 * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值，究竟哪个才是真正的用户端的真实IP呢？
	 * 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串。
	 * 
	 * 如：X-Forwarded-For：192.168.1.110, 192.168.1.120, 192.168.1.130, 192.168.1.100
	 * 
	 * 用户真实IP为： 192.168.1.110
	 * 
	 * @param request
	 * @return
	 */
	public static String getIpAddress(HttpServletRequest request) {
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			if (StringUtils.isNoneBlank(headerNames.nextElement())) {
				try {

					LOGGER.info("header {}++{}", headerNames.nextElement(),
							request.getHeader(headerNames.nextElement()));
				} catch (Exception e) {
					LOGGER.error(
							"coding headerNames.nextElement() or request.getHeader(headerNames.nextElement()) error");
					ExceptionUtil.getTrace(e);
				}
			} else {

				LOGGER.error("headerNames.nextElement() is null");
			}
		}
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Real-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	public static boolean isInnerIp(String ip) {
		if (StringUtils.equals("127.0.0.1", ip)) {
			return true;
		}
		if(StringUtils.startsWith(ip, "10.") || StringUtils.startsWith(ip, "172.") || StringUtils.startsWith(ip, "192.")) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * <p>Description:获取解密后的key </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月12日 下午4:40:34
	 * @param key
	 * @return
	 */
	private String getJsonDataBySecretKey(String key){
		
		try {
		    URL realUrl;
		    HttpURLConnection conn = null;
		    BufferedReader bufferedReader = null;
			
		    String jsonKey="";
			if (StringUtils.isNoneBlank(getKeyUrl)) {
				
				//mgmt获取解密的key
				realUrl = new URL(getKeyUrl);
				conn = (HttpURLConnection) realUrl.openConnection();
				
				bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line;
				if ((line = bufferedReader.readLine()) != null) {
					jsonKey += line;
				}
				if (StringUtils.isNoneBlank(jsonKey)) {
					ObjectMapper mapper = new ObjectMapper();
					WantWebServiceData wantWsData = mapper.readValue(jsonKey, WantWebServiceData.class);
					
					if (StringUtils.isNoneBlank(wantWsData.getData())) {
						
						//解密数据库加密的key
						DesUtils des = new DesUtils("ThisIsSecret");
						String key4Json = des.decrypt(wantWsData.getData());
						
						//再用解密好的数据库的key去解密第三方系统传进来
						key = WantDes4Sso.DES_CBC_Decrypt(key, key4Json);
						return key;
					}
				}
			}
			
			
		} catch (Exception e) {
			LOGGER.error("第三方系统集成登入爱旺旺解密key出现异常");
			e.printStackTrace();
			return key;
		}
		return key;
	}
	
	/**
	 * 
	 * <p>Description:新的经销商网站的挂载URL的爱旺旺入口 </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年4月28日 下午5:52:36
	 * @param request
	 * @param url
	 * @return
	 */
	@RequestMapping(value="icustomer_url")
	public ModelAndView login2IcustomerUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url){
		ModelAndView mv = new ModelAndView();
		try {
			
			//获取本地cookie
			String vt="";
			try {
				//获取爱旺旺的vt
				vt = CookieUtil.getCookieValue(request, "vt", true);
			} catch (Exception e) {
				mv.setViewName(loginConfig.getLoginViewName());
				return mv;
			}
			
			if (StringUtils.isNoneBlank(vt)) {
				//获取加密key
				String key = this.getIcustomerSsoKey(iCustomerLoginDesKey);
				if (StringUtils.isNoneBlank(key)) {
					//拼接请求的JSON
					String icustomerJson = CustomerUtil.makeIcustomerJson(vt, "http://"+url,want2IcustomerSignId);
					String icustomerJsonDes = WantDes4Sso.DES_CBC_Encrypt(icustomerJson, key);
					if (StringUtils.isNoneBlank(icustomerJsonDes)) {
						mv.setViewName("redirect:" + iCustomerLoginGhostUrl + URLEncoder.encode(icustomerJsonDes, "UTF-8"));
						LOGGER.info("爱旺旺开始跳转到新的经销商网站");
						return mv;
					} else {
						
						LOGGER.error("爱旺旺2.0登入到经销商网站，拼接的JSON为空");
						RedirectView redirectView = new RedirectView(iCustomerLoginUrl);
						return new ModelAndView(redirectView);
					}
				}else{
					
					//若到经销商的mgmt模块获取加密的key为空则返回到经销商模块
					LOGGER.error("爱旺旺2.0登入到经销商网站，获取DES加密的key为空");
					RedirectView redirectView = new RedirectView(iCustomerLoginUrl);
					return new ModelAndView(redirectView);
				}
				
			}else{
				mv.setViewName(loginConfig.getLoginViewName());
				return mv;
			}
			
		} catch (Exception e) {
			LOGGER.error("爱旺旺2.0挂载的链接登入到经销商网站，出现异常，链接是："+url+"，异常信息是"+e.getMessage());
			RedirectView redirectView = new RedirectView(iCustomerLoginUrl);
			return new ModelAndView(redirectView);
		}
	}
}
