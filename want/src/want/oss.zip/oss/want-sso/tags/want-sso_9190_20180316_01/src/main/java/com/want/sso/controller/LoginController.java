/*
 * -------------------------------------------------------
 * @FileName LoginController.java
 * @Description 用户登录登出相关方法
 * @Author 00294476
 * @Copyright www.want-want.com Ltd. All rights reserved.
 * 注意：本内容仅限于旺旺集团内部传阅，禁止外泄以及用于其他商业目的
 * -------------------------------------------------------
 */
package com.want.sso.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.common.pojo.SsoUser;
import com.want.common.service.RedisService;
import com.want.common.util.CookieUtil;
import com.want.common.util.ExceptionUtil;
import com.want.sso.pojo.LoginConfig;
import com.want.sso.service.ILdapService;
import com.want.sso.utils.CryptAES;

/**
 * @description 登录的controller
 * @author 00294476
 * @version V1.0.0
 */
@Controller
public class LoginController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	private static final ObjectMapper MAPPER = new ObjectMapper();

	@Autowired
	private LoginConfig loginConfig;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ILdapService ldapService;

	@Value(value = "${innerSepSystemUrl}")
	private String innerSepSystemUrl;
	
	@Value(value = "${outerSepSystemUrl}")
	private String outerSepSystemUrl;

	/**
	 * <登录方法，给二级系统做logincheck>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam(value = "backUrl", required = false) String backUrl) {

		ModelAndView mv = new ModelAndView();
		String vt = "";
		try {
			vt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getVtCookieName(), true);
		} catch (UnsupportedEncodingException e1) {
			LOGGER.error("获取cookie vt失败{}", ExceptionUtil.getTrace(e1));
		}
		if (StringUtils.isNotEmpty(vt)) {
			/* vt存在 */
			// 从redis里面取出来vt user
			byte[] byteSsoUser = redisService.get(vt);
			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({}) check success !", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				/*
				 * *********************** 临时添加icustomer验证， 当判读是经销商的时候，跳转到SEP，
				 * 等icustomer2.0网站完成后，注释这段代码
				 * 
				 * 00294476
				 */
				try {
					SsoUser ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
					boolean flag = ldapService.isCustomer(ssoUser.getAccount());
					if (flag) {
						String ipAddress = getIpAddress(httpServletRequest);
						LOGGER.info("enter ipAddress:{}", ipAddress);
						if (isInnerIp(ipAddress)) {
							CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
							mv.setViewName("redirect:" + innerSepSystemUrl);
						} else {
							CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
							mv.setViewName("redirect:" + outerSepSystemUrl);
						}
					} else {
						mv.setViewName("redirect:" + loginConfig.getPortalUrl());
					}
				} catch (Exception e) {
					LOGGER.error(ExceptionUtil.getTrace(e));
				}
				

				// mv.setViewName("redirect:" +
				// loginConfig.getPortalUrl());//等icustomer2.0网站完成后，释放这段代码
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({}) check false !", vt);
				validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			String lt = "";
			try {
				lt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getLtCookieName(), true);
			} catch (UnsupportedEncodingException e1) {
				LOGGER.error("获取cookie lt失败{}", ExceptionUtil.getTrace(e1));
			}
			if (StringUtils.isNotEmpty(lt)) {
				/* lt存在 */
				// 从redis里面取出来lt user
				byte[] byteSsoUser = redisService.get(lt);
				if (byteSsoUser != null) {
					LOGGER.info("当前的lt({})用户从redis中获取成功", lt);
					/* lt验证成功 */
					try {
						SsoUser ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
						validateSucceed(httpServletRequest, httpServletResponse, backUrl, ssoUser, false, mv);
					} catch (Exception e) {
						LOGGER.error(ExceptionUtil.getTrace(e));
					}
				} else {
					/* redis里面没有lt用户 */
					LOGGER.info("当前的lt({})用户从redis中获取失败", lt);
					validateFailed(backUrl, mv);
				}
			} else {
				/* lt也不存在，表示没有remember me */
				// 执行validateFailed
				validateFailed(backUrl, mv);
			}
		}
		return mv;
	}

	/**
	 * <页面登录>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param user
	 * @param backUrl
	 * @param rememberMe
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView login(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			SsoUser user, @RequestParam(value = "backUrl", required = false) String backUrl,
			@RequestParam(value = "rememberMe", required = false) boolean rememberMe) {

		ModelAndView mv = new ModelAndView();
		LOGGER.info("start login username={}", user.getAccount());
		try {
			boolean isLogon = ldapService.loginAD(user.getAccount(), user.getPassword());
			if (isLogon) {
				LOGGER.info("login success !");
				/* ad验证成功 */
				validateSucceed(httpServletRequest, httpServletResponse, backUrl, user, rememberMe, mv);
			} else {
				validateFailed(backUrl, mv);
				// mv.addObject("error", "用户名或者密码不正确");
				mv.addObject("error", "密码输入错误三次，帐号将被锁");
			}
		} catch (Exception e) {
			validateFailed(backUrl, mv);
			mv.addObject("error", "服务器内部错误");
			LOGGER.error(ExceptionUtil.getTrace(e));
		}
		return mv;
	}

	/**
	 * <验证失败时，判断是否重新登录的操作>
	 * 
	 * @param backUrl
	 * @param mv
	 */
	private void validateFailed(String backUrl, ModelAndView mv) {
		if (StringUtils.isNoneEmpty(backUrl)) {
			mv.addObject("backUrl", backUrl);
		}
		// 转到登录页面
		mv.setViewName(loginConfig.getLoginViewName());
	}

	/**
	 * <vt验证失败，生成vt，按需添加lt>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @param ssoUser
	 * @param rememberMe
	 * @param mv
	 * @throws Exception
	 */
	private void validateSucceed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			String backUrl, SsoUser ssoUser, boolean rememberMe, ModelAndView mv) throws Exception {

		// 加密工号--00319159  2017年12月18日14:47:09
		String password = ssoUser.getPassword();
		String aes_Encrypt = CryptAES.AES_Encrypt("1234567890123456", password);
		ssoUser.setPassword(aes_Encrypt);
		
		if (rememberMe) {
			/* rememberMe=true时，表示lt已失效 */
			// 重新生成lt
			String lt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
			// 添加ltcookie
			CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName(), lt, true);
			// 添加用户到redis
			redisService.set(lt, MAPPER.writeValueAsString(ssoUser), loginConfig.getLtRedisMaxTime());
			LOGGER.info("remember me new lt={}", lt);
		}
		// 生成vt
		String vt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		// 添加vtcookie
		CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName(), vt, true);
		// 添加vt用户到redis
		redisService.set(vt, MAPPER.writeValueAsString(ssoUser), loginConfig.getVtRedisMaxTime());
		LOGGER.info("new vt={}", vt);
		/*
		 * ************************ 临时添加icustomer验证， 当判读是经销商的时候，跳转到SEP，
		 * 等icustomer2.0网站完成后，注释这段代码
		 * 
		 * 00294476
		 */
		boolean flag = ldapService.isCustomer(ssoUser.getAccount());
		if (flag) {

			String ipAddress = getIpAddress(httpServletRequest);
			LOGGER.info("enter ipAddress:{}", ipAddress);
			if (isInnerIp(ipAddress)) {
				mv.setViewName("redirect:" + innerSepSystemUrl);
			} else {
				mv.setViewName("redirect:" + outerSepSystemUrl);
			}

		} else if (StringUtils.isNotEmpty(backUrl)) {
			mv.setViewName("redirect:" + backUrl);
		} else {
			mv.setViewName("redirect:" + loginConfig.getPortalUrl());
		}

		/*
		 * 等icustomer2.0网站完成后，释放这段代码 00294476 if (StringUtils.isNotEmpty(backUrl)) {
		 * mv.setViewName("redirect:" + backUrl); } else { mv.setViewName("redirect:" +
		 * loginConfig.getPortalUrl()); }
		 */

	}

	/**
	 * <登出>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @throws Exception
	 * @throws ClientProtocolException
	 */
	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
			throws Exception {

		ModelAndView mv = new ModelAndView();
		String vt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getVtCookieName(), true);
		if (StringUtils.isNotEmpty(vt)) {
			// 删除cookie(vt)
			CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName());
			// 删除redis中的登录的用户
			redisService.delete(vt);
			String lt = CookieUtil.getCookieValue(httpServletRequest, loginConfig.getLtCookieName(), true);
			if (StringUtils.isNotEmpty(lt)) {
				// 删除cookie(lt)
				CookieUtil.deleteCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName());
				// 删除redis中的免登陆用户
				redisService.delete(lt);
			}
		}
		LOGGER.info("logout success vt={}", vt);
		mv.setViewName(loginConfig.getLoginViewName());
		return mv;
	}

	/**
	 * 获取用户真实IP地址，不使用request.getRemoteAddr();的原因是有可能用户使用了代理软件方式避免真实IP地址
	 * 
	 * 可是，如果通过了多级反向代理的话，X-Forwarded-For的值并不止一个，而是一串IP值，究竟哪个才是真正的用户端的真实IP呢？
	 * 答案是取X-Forwarded-For中第一个非unknown的有效IP字符串。
	 * 
	 * 如：X-Forwarded-For：192.168.1.110, 192.168.1.120, 192.168.1.130, 192.168.1.100
	 * 
	 * 用户真实IP为： 192.168.1.110
	 * 
	 * @param request
	 * @return
	 */
	public static String getIpAddress(HttpServletRequest request) {
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			if (StringUtils.isNoneBlank(headerNames.nextElement())) {
				try {

					LOGGER.info("header {}++{}", headerNames.nextElement(),
							request.getHeader(headerNames.nextElement()));
				} catch (Exception e) {
					LOGGER.error(
							"coding headerNames.nextElement() or request.getHeader(headerNames.nextElement()) error");
					ExceptionUtil.getTrace(e);
				}
			} else {

				LOGGER.error("headerNames.nextElement() is null");
			}
		}
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Real-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	public static boolean isInnerIp(String ip) {
		if (StringUtils.equals("127.0.0.1", ip)) {
			return true;
		}
		if(StringUtils.startsWith(ip, "10.") || StringUtils.startsWith(ip, "172.") || StringUtils.startsWith(ip, "192.")) {
			return true;
		}
		return false;
	}

}
