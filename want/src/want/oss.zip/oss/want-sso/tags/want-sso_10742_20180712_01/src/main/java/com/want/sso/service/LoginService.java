package com.want.sso.service;

import com.want.sso.pojo.LoginUserByKey;

public interface LoginService {

	/**
	 * 
	 * <p>Description:通过key获取注册登入到爱旺旺的URL</p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年7月2日 上午10:22:37
	 * @param key 第三方系统的key
	 * @return
	 * @throws Exception
	 */
	public String getRegisterUrlByKey(LoginUserByKey user) throws Exception;
}
