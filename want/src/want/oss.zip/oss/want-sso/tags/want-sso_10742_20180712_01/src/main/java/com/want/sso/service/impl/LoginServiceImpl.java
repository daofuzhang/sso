package com.want.sso.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.want.sso.mapper.LoginMapper;
import com.want.sso.pojo.LoginUserByKey;
import com.want.sso.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginMapper loginMapper;

	@Override
	public String getRegisterUrlByKey(LoginUserByKey user) throws Exception {
		//查询数据库中注册的URL
		return this.loginMapper.selectIntegrateUrlByKey(user.getOsType());
	}
	

}
