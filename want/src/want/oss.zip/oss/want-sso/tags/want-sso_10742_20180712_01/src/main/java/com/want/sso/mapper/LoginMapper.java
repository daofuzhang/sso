package com.want.sso.mapper;

public interface LoginMapper {

	/**
	 * 
	 * <p>Description:查询数据库中注册的URL </p>
	 * <p>Company:want-want </p>
	 * @author 00301082
	 * @date 2018年7月2日 上午10:26:06
	 * @param osType
	 * @return
	 */
	public String selectIntegrateUrlByKey(String osType);

}
