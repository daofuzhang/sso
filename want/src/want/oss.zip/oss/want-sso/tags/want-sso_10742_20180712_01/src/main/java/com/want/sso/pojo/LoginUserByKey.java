package com.want.sso.pojo;

public class LoginUserByKey {

	//登入的key
	private String key;
	
	//第三方系统的类型
	private String osType;
	
	//需要跳转到爱旺旺的第三方系统
	private String backUrl;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getOsType() {
		return osType;
	}

	public void setOsType(String osType) {
		this.osType = osType;
	}

	public String getBackUrl() {
		return backUrl;
	}

	public void setBackUrl(String backUrl) {
		this.backUrl = backUrl;
	}

	@Override
	public String toString() {
		return "LoginUserByKey [key=" + key + ", osType=" + osType + ", backUrl=" + backUrl + "]";
	}
	
}
