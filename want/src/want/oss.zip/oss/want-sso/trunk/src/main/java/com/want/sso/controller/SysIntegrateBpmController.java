package com.want.sso.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.want.common.pojo.SsoUser;
import com.want.common.service.RedisService;
import com.want.common.util.CookieUtil;
import com.want.common.util.ExceptionUtil;
import com.want.sso.pojo.LoginConfig;
import com.want.sso.service.ILdapService;
import com.want.sso.utils.CustomerUtil;
import com.want.sso.utils.DesUtils;

/**
 * 
 * <p>Title:系统集成 </p>
 * <p>Description:集成Bpm系统</p>
 * <p>Company:旺旺集团</p>
 * @author 00301082
 * @date 2017年7月4日 上午10:46:10
 */
@Controller
@RequestMapping(value = "integrationBpm")
public class SysIntegrateBpmController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SysIntegrateBpmController.class);
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	@Autowired
	private LoginConfig loginConfig;

	@Autowired
	private RedisService redisService;
	
	@Autowired
	private ILdapService ldapService;
	
	//bw销售报表
	@Value(value = "${bwSalesUrl}")
	private String bwSalesUrl;
	
	//跳转链接的url，经过她可以将登入信息写入系统和浏览器中
	@Value(value = "${bridgeUrl}")
	private String bridgeUrl;
	
	//真正跳转链接的url
	@Value(value = "${bwProducUrl}")
	private String bwProducUrl;
	
	//真正跳转链接的url
	@Value(value = "${bwAcountUrl}")
	private String bwAcountUrl;
	
	//真正跳转链接的url
	@Value(value = "${bwSupplyUrl}")
	private String bwSupplyUrl;
	
	//真正跳转链接的url
	@Value(value = "${lowProduct}")
	private String lowProduct;
	
	//真正跳转链接的url 人事系统
	@Value(value = "${hRBridgeUrl}")
	private String hRBridgeUrl;
	
	//真正跳转链接的url 业务系统测试环境
	@Value(value = "${nwqBridgeUrl}")
	private String nwqBridgeUrl;
	
	//真正跳转链接的url nwcep73测试环境
	@Value(value = "${nwcep73BridgeUrl}")
	private String nwcep73BridgeUrl;
	
	//真正跳转链接的url enpdev开发环境
	@Value(value = "${epndevBridgeUrl}")
	private String epndevBridgeUrl;
	
	//真正跳转链接的url nwd开发环境
	@Value(value = "${nwdBridgeUrl}")
	private String nwdBridgeUrl;
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectFormView")
	public ModelAndView redirectFormView(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		String url = "http://epndev:50400/bpm/search/index.jsp?classId=CX";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://epndev:50400/manage-infov3/redirectIwant2?vt="+urlAndVt;
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法BW报表</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectBwGui")
	public ModelAndView redirectBwGui(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		
		String getUrl = "http://nwcep73:50600/manage-infov3/loading?vt="+vt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法ERPGui</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("redirectERPGui")
	public void redirectERPGui(HttpServletRequest request,HttpServletResponse response) throws IOException{
		
		//返回的状态 若为空则表示没有请求成功
		//String status = "";
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		//TODO
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		
		try {
			//URL url = new URL("http://nwcep73:50600/manage-infov3/getUrlAndReturnWant2?vt=" + vt); //测试环境
			URL url = new URL("http://epndev:50400/manage-infov3/getUrlAndReturnWant2?vt=" + vt); //开发环境
			try {
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				InputStream is = conn.getInputStream();
		        conn.connect();
		        byte[] buff = new byte[is.available()];
		        is.read(buff);
		        //status = new String(buff, "utf-8");
		        conn.disconnect();
		        is.close();
			} catch (IOException e) {
				LOGGER.error("向NW平台发送请求的时候出现了异常");
				e.printStackTrace();
			}finally {
				//this.postHttpToERPGui(request,response);
			}
		} catch (MalformedURLException e) {
			LOGGER.error("向NW平台请求的时候出URL现了异常");
			e.printStackTrace();
		}
	}
	
	
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 GUI ERP(windows)</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAPCRM")
	public ModelAndView redirectSAPCRM(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://crmap1.want-want.com:8003/sap/bc/bsp/sap/crm_ui_start/default.htm";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
//		getUrl = "http://epndev.want-want.com:50400/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		//getUrl = "http://epndev.want-want.com:50400/iwant2sso/redirectIwant2?vt="+urlAndVt;
		//getUrl = "http://epndev:50400/iwant2sso/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 GUI ERP(windows)</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectNWD")
	public ModelAndView redirectNWD(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://nwd:50000/irj/portal";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 跳转到portal</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectNWDPortal")
	public ModelAndView redirectNWDPortal(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://nwd:50000/irj/portal?vt="+vt;
		
		return new ModelAndView(new RedirectView(url));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 GUI ERP(windows)</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectNWDLoginModule")
	public ModelAndView redirectNWDLoginModule(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://nwd:50000/irj/portal";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwd:50000/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 SAP系统中的 ERP</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAP_ERP")
	public ModelAndView redirectSAP_ERP(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://sapqas.want-want.com:8000/sap(ZT1VRERPNExqdjJiNHgwdzVOQ0dlSTlRLS10dHl1UXZvVHhPbEZGWnhnX3N5SWN3LS0=)/bc/gui/sap/its/webgui?&sap-sessioncmd=USR_ABORT&~SAPSessionCmd=USR_ABORT&SAPWP_ACTIVE=1&dsmguid=1499821899222";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 SAP系统中的 BO</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAP_BO")
	public ModelAndView redirectSAP_BO(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://boe.want-want.com/BOE/BI";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 SAP系统中的 CRM</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAP_CRM")
	public ModelAndView redirectSAP_CRM(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://crmap1.want-want.com:8003/sap/bc/bsp/sap/crm_ui_start/default.htm";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 SAP系统中的 SRM</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAP_SRM")
	public ModelAndView redirectSAP_SRM(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://srmjs.want-want.com:51100/irj/portal";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	
	/**
	 * 
	 * <p>Description: sap系统get请求携带多个参数的请求方法 SAP系统中的 BPC</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月4日 上午8:43:28
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("redirectSAP_BPC")
	public ModelAndView redirectSAP_BPC(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		//销售计划偏差与业绩偏差报表-目标业绩偏差率
		String url = "http://bpc.want-want.com:8000/sap/bpc/web";
		//请求的参数
		String urlAndVt = "";
		//请求的路径和参数
		String getUrl = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",{");
		urlAndVtBuffer.append(url);
		urlAndVtBuffer.append("}");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/redirectIwant2?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	/**
	 * 
	 * <p>Description:通过加密之后发送一些特别长的http请求地址或
	 *    带特殊字符的http请求地址</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月14日 上午10:18:37
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("encodSAP_ERP")
	public ModelAndView encodSAP_ERP(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		String url = "http://nwcep73.want-want.com:50600/irj/servlet/prt/portal/prtroot/pcdshort!3a!2fk3OPd6cw8Mdn!2bqnYl8BYZYGuXnA!3d/tx.sap?NavMode=0&windowId=WID1500024155519&CurrentWindowId=WID1500024155519&ExecuteLocally=true&PrevNavTarget=navurl%3A%2F%2F51fe5b4910432aa51dd9d666f3ccbaa6&%24Roundtrip=true&%24DebugAction=null";
		
		//开始加密
		DesUtils des = new DesUtils("secret"); //自定义密钥secret
		String encryptUrl = "";
		try {
			//加密后请求的参数
			encryptUrl = des.encrypt(url);
		} catch (Exception e) {
			LOGGER.error("http请求链接出现异常");
			e.printStackTrace();
		}
		
		//get 参数
		String urlAndVt = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",[");
		urlAndVtBuffer.append(encryptUrl);
		urlAndVtBuffer.append("]");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		//请求的路径和参数
		String getUrl = "";
		getUrl = "http://nwcep73.want-want.com:50600/manage-infov3/encod?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	
	/**
	 * 
	 * <p>Description:通过加密之后发送一些特别长的http请求地址或
	 *    带特殊字符的http请求地址</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月14日 上午10:18:37
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("encod_AssetManage")
	public ModelAndView encod_AssetManage(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("BPM system redirect to query form view");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		if(StringUtils.isBlank(vt)){
			//http://i2test3.want-want.com/want-sso/
		}
		String url = "http://psys.want-want.com:7217/FIXED_WEB/addformservlet?ACTION=PREPAREADD";
		
		//开始加密
		DesUtils des = new DesUtils("secret"); //自定义密钥secret
		String encryptUrl = "";
		try {
			//加密后请求的参数
			encryptUrl = des.encrypt(url);
		} catch (Exception e) {
			LOGGER.error("http请求链接出现异常");
			e.printStackTrace();
		}
		
		//get 参数
		String urlAndVt = "";
		
		//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
		StringBuffer urlAndVtBuffer = new StringBuffer();
		urlAndVtBuffer.append("\"");
		urlAndVtBuffer.append(vt);
		urlAndVtBuffer.append(",[");
		urlAndVtBuffer.append(encryptUrl);
		urlAndVtBuffer.append("]");
		urlAndVtBuffer.append("\"");
		urlAndVt = urlAndVtBuffer.toString();
		
		//请求的路径和参数
		String getUrl = "";
		getUrl = "http://epndev:50400/manage-infov3/encod?vt="+urlAndVt;
		
		return new ModelAndView(new RedirectView(getUrl));
	}
	
	
	/**
	 * 
	 * <p>Description: 通用的跳转方法，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("encod_Common")
	public ModelAndView encod_Common(HttpServletRequest request) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统...");
			String url = "http://epndev:50400/irj/servlet/prt/portal/prtroot/pcd!3aportal_content!2fcom.sap.pct!2fplatform_add_ons!2fcom.sap.ip.bi!2fiViews!2fcom.sap.ip.bi.bex?TEMPLATE=ZWPP_ZPP_WW_ZPP_MC01_Q0002NEW";
			

			
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			getUrl = "http://epndev:50400/manage-infov3/encod?vt="+data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:销售bw报表下载 通用的跳转方法，数据格式是json</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("bw_sales_common")
	public ModelAndView bwSalesCommon(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = bwSalesUrl + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	
	/**
	 * 
	 * <p>Description:制造、品保，研发 通用的跳转方法，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("bw_product_common")
	public ModelAndView bwProductCommon(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = bwProducUrl + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	
	/**
	 * 
	 * <p>Description:财务BW报表 通用的跳转方法，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("bw_acount_common")
	public ModelAndView bwAcountCommon(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = bwAcountUrl + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:供应链bw报表 通用的跳转方法，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("bw_supply_common")
	public ModelAndView bwSupplyCommon(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = bwSupplyUrl + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	
	/**
	 * 
	 * <p>Description:低耗品管理系统 通用的跳转方法，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("lowProduct_common")
	public ModelAndView lowProductCommon(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = lowProduct + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("other/common_url")
	public ModelAndView otherCommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = "http://" + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = bridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("hRCommonUrl")
	public ModelAndView hRCommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = "http://" + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = hRBridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割,NWQ 环境</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("nwqCommonUrl")
	public ModelAndView nwqCommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = "http://" + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = nwqBridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割,nwcep73 环境</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("nwcep73CommonUrl")
	public ModelAndView nwcep73CommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统nwcep73或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//通过cookie获取当前登入人
		String account = "";
		try {
			SsoUser ssoUser = this.getUserByVt(request, "");
			if (ssoUser !=null) {
				account = ssoUser.getAccount();
			}
		} catch (Exception e) {
			//以防万一设置为非空
			account="notNull";
			e.printStackTrace();
		}
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		//判断要跳转的url有没有带参数
		url = getRedirectUrl(request, url);
		
		//cookie 
		if(StringUtils.isNotBlank(vt) && StringUtils.isNoneBlank(account)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = nwcep73BridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}

	//判断要跳转的url有没有带参数
	private String getRedirectUrl(HttpServletRequest request, String url) {
		StringBuffer sb = new StringBuffer("");
		
		//取出请求中所有的参数名称
		Iterator<String> it = request.getParameterMap().keySet().iterator();
		
		//如果有带参数，加入要跳转的url
//		int i = 0;
		while (it.hasNext()) {
			String param = it.next();
			if (!param.equals("url")) {
				sb.append("&").append(param).append("=").append(request.getParameterMap().get(param)[0]);
//可参考：sb.append("&").append(param).append("=").append(request.getParameterMap().get(param)[0]);是原来的版本
//				if (i==0) {
//					
//					sb.append("?").append(param).append("=").append(request.getParameterMap().get(param)[0]);
//					i++;
//				} else {
//
//					sb.append("&").append(param).append("=").append(request.getParameterMap().get(param)[0]);
//					i++;
//				}
			}
		}
		url = "http://" + url + sb.toString();
		System.out.println("url = " + url);
		return url;
	}
	
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割,epndev 环境</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("epndevCommonUrl")
	public ModelAndView epndevCommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统nwcep73或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = "http://" + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = epndevBridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	
	/**
	 * 
	 * <p>Description:对于一些不是很有规律的链接做单独处理，数据格式是字符串用 } 分割,epndev 环境</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月17日 下午1:40:57
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("nwdCommonUrl")
	public ModelAndView nwdCommonUrl(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统nwcep73或链接的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		
		//通过cookie获取当前登入人
		String account = "";
		try {
			SsoUser ssoUser = this.getUserByVt(request, "");
			if (ssoUser !=null) {
				account = ssoUser.getAccount();
			}
		} catch (Exception e) {
			//以防万一设置为非空
			account="notNull";
			e.printStackTrace();
		}
		
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		
		url = "http://" + url;
		
		//cookie 
		if(StringUtils.isNotBlank(vt) && StringUtils.isNoneBlank(account)){
			LOGGER.info("开始跳转第三方系统{}低耗品管理系统...");
			//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
			StringBuffer urlAndVtBuffer = new StringBuffer();
			urlAndVtBuffer.append(vt);
			urlAndVtBuffer.append("}");
			urlAndVtBuffer.append(url);
			urlAndVt = urlAndVtBuffer.toString();
			
			
			//加密之后请求的路径和参数
			String getUrl = "";
			//开始加密
			DesUtils des = new DesUtils("secret"); //自定义密钥secret
			
			try {
				//加密后请求的参数
				data = des.encrypt(urlAndVt);
			} catch (Exception e) {
				LOGGER.error("http请求链接出现异常");
				e.printStackTrace();
			}
			
			//跳转的方法，起到桥梁的作用
			getUrl = nwdBridgeUrl + data;
			
			RedirectView redirectView = new RedirectView(getUrl);
			return new ModelAndView(redirectView);
		}else{
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
		
	}
	
	/**
	 * 
	 * <p>Description: 跳转到第三方系统时候，第三方系统不用再重定向跳转</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年9月14日 下午4:00:26
	 * @param request
	 * @param url
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("static-access")
	@RequestMapping("commonUrlMaster")
	public ModelAndView commonUrlMaster(HttpServletRequest request,@RequestParam(value="url",required=false)String url) throws UnsupportedEncodingException{
		
		LOGGER.info("开始调用第三方系统的通用方法....");
		//获取本地cookie
		String vt = CookieUtil.getCookieValue(request, "vt", true);
		//加密前的参数
		String urlAndVt = "";
		//加密的数据
		String data = "";
		String headUrl = "http://" + url;
		url = "http://" + url;
		
		try {
			//cookie 
			if(StringUtils.isNotBlank(vt)){
				//拼接vt和最终要请求的UR的get参数的L格式是:vt"{url}"
				StringBuffer urlAndVtBuffer = new StringBuffer();
				urlAndVtBuffer.append(vt);
				urlAndVtBuffer.append("}");
				urlAndVtBuffer.append(url);
				urlAndVt = urlAndVtBuffer.toString();
				
				
				//加密之后请求的路径和参数
				String getUrl = "";
				//开始加密
				DesUtils des = new DesUtils("secret"); //自定义密钥secret
				
				try {
					//加密后请求的参数
					data = des.encrypt(urlAndVt);
				} catch (Exception e) {
					LOGGER.error("http请求链接出现异常");
					e.printStackTrace();
				}
				
				//跳转的方法，起到桥梁的作用
				getUrl = headUrl +"?vt="+ data;
				
				RedirectView redirectView = new RedirectView(getUrl);
				return new ModelAndView(redirectView);
			}else{
				LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
				ModelAndView mv = new ModelAndView();
				mv.setViewName(loginConfig.getLoginViewName());
				return mv;
			}
		} catch (Exception e) {
			LOGGER.error("获得的cookie{vt}为空，发生异常空指针异常....");
			ModelAndView mv = new ModelAndView();
			mv.setViewName(loginConfig.getLoginViewName());
			return mv;
		}
	}
	
	
	/**
	 * 
	 * <p>Description:nw系统集成和ear包通信的方法  </p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年9月13日 下午2:57:49
	 * @param request
	 * @param vt
	 * @return
	 */
	@RequestMapping(value = "validate_service", method = RequestMethod.GET)
	public @ResponseBody String systemIntegration(HttpServletRequest request,
			@RequestParam(value = "vt", required = false) String vt) {
		LOGGER.info("系统集成跳转出第三方系统回来验证{vt}时，开始检验。。。。。");
		String account="";
		try {
			String url = "";
			//爱旺旺1.0ear传回来的vt去获取用户名
			SsoUser ssoUser = this.getUserByVtUseVt(request, url, vt);
			if (ssoUser != null) {
				boolean isCustomerNotFormat = false;
				boolean isCustomerFormat = false;
				if (StringUtils.isNoneBlank(ssoUser.getAccount())) {
					
					//从redis获取的工号不包涵-1(有可能是员工也有可能是经销商)
					if (!ssoUser.getAccount().contains("-1")) {
						
						//是员工
						if (ldapService.isUser(ssoUser.getAccount())) {
							
							account = ssoUser.getAccount();
						}else{
							
							//未格式化加-1
							isCustomerNotFormat = ldapService.isCustomer(ssoUser.getAccount());
							//格式化加-1
							String customerIdFormatForLdap = CustomerUtil.customerIdFormatForLdap(ssoUser.getAccount());
							isCustomerFormat = ldapService.isCustomer(customerIdFormatForLdap);
							
							if (isCustomerNotFormat || isCustomerFormat) {//是经销商
								
								if (isCustomerNotFormat) {
									
									account = ssoUser.getAccount();
								}else if(isCustomerFormat){
									account = customerIdFormatForLdap;
								}
							}else{//公司员工
								
								account = ssoUser.getAccount();
								LOGGER.info("系统集成跳转出第三方系统回来验证{vt}时，获取到的工号："+account);
							}
						}
					}else{//包涵-1（经销商）
						
						account = ssoUser.getAccount();
					}
					
				}
				
			}
		} catch (Exception e) {
			LOGGER.error("系统集成跳转出第三方系统回来验证{vt}时，出现了异常");
			LOGGER.error(ExceptionUtil.getTrace(e));
		}
		LOGGER.info("系统集成跳转出第三方系统回来验证{vt}时，成功返回的工号或经销商ID："+account);
		//返回用户名
		return account;
	}
	
	
	@RequestMapping(value = "validate_icustomer", method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> icustomerSysValidate(HttpServletRequest request,
			@RequestParam(value = "key", required = false) String vt) {
		LOGGER.info("经销商系统返回key校验{key}是："+vt);
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			String url = "";
			//经销商传回来的key去获取用户名
			SsoUser ssoUser = this.getUserByVtUseVt(request, url, vt);
			if (ssoUser != null) {
				String account = ssoUser.getAccount();
				map.put("data", account);
				map.put("status", true);
				LOGGER.info("经销商系统返回验证{key}时，获取到的经销商ID：" + account);
			}else{
				
				map.put("data", "");
				map.put("status", true);
				LOGGER.info("经销商系统返回验证{key}时，获取到的经销商ID为空");
			}
		} catch (Exception e) {
			map.put("data", "");
			map.put("status", false);
			LOGGER.error("经销商系统返回验证{key}时，出现了异常");
			LOGGER.error(ExceptionUtil.getTrace(e));
		}
		LOGGER.info("系统集成跳转出第三方系统回来验证{vt}时，成功返回数据："+map);
		return map;
	}
	
	/**
	 * 
	 * <p>Description: 爱旺旺2.0传回来的连接然后跳转到1.0的ear登入模块</p>
	 * <p>Company:旺旺集团 </p>
	 * @author 00301082
	 * @date 2017年7月6日 下午3:01:19
	 * @param request
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("want2ToWant1GetCookie")
	public ModelAndView want2ToWant1GetCookie(HttpServletRequest request) throws Throwable{
		
		String getUrl = "http://epndev:50400/irj/portal";
		String vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(getUrl);
		strBuffer.append("?vt=");
		strBuffer.append(vt);
		
		//跳转到爱旺旺1.0的portal
		return new ModelAndView(new RedirectView(strBuffer.toString()));
	}
	
	
/****************************************************************************************************************************/	
	/**
	 * 通过vt获取当前登录用户信息
	 * @author 00319159
	 * 下午3:59:44
	 * @param vt
	 * @return
	 *  旺旺集团
	 * @throws UnsupportedEncodingException 
	 */
	public  SsoUser getUserByVt(HttpServletRequest request,String backUrl) throws Exception{
		ModelAndView mv = new ModelAndView();
		String vt = "";
		try {
			vt = CookieUtil.getCookieValue(request, loginConfig.getVtCookieName(), true);
		} catch (Exception e1) {
			LOGGER.error("获取cookie vt失败{}", ExceptionUtil.getTrace(e1));
		}
		SsoUser ssoUser = null;
		/* vt存在 */
		if (StringUtils.isNotEmpty(vt)) {
			// 从redis里面取出来realVt（vt)
			byte[] byteSsoUser = redisService.get(vt);

			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({})获取用户信息成功!", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				try {
					ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
				} catch (IOException e) {
					e.printStackTrace();
					/* 登录过期，转入登录页面 */
					LOGGER.error("获取redis内用户失败vt({}) check false !", vt);
					this.validateFailed(backUrl, mv);
				}
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({})获取用户失败!", vt);
				this.validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			this.validateFailed(backUrl, mv);
		}
		return ssoUser;
	}
	
	
	/**
	 * 通过传过来的vt获取当前登录用户信息
	 * @author 00319159
	 * 下午3:59:44
	 * @param vt
	 * @return
	 *  旺旺集团
	 * @throws UnsupportedEncodingException 
	 */
	public  SsoUser getUserByVtUseVt(HttpServletRequest request,String backUrl,String vt) throws Exception{
		ModelAndView mv = new ModelAndView();
		SsoUser ssoUser = null;
		/* vt存在 */
		if (StringUtils.isNotEmpty(vt)) {
			// 从redis里面取出来realVt（vt)
			byte[] byteSsoUser = redisService.get(vt);

			if (byteSsoUser != null) {
				/* vt验证成功 */
				LOGGER.info("vt({})获取用户信息成功!", vt);
				redisService.expire(vt, loginConfig.getVtRedisMaxTime());

				try {
					ssoUser = MAPPER.readValue(byteSsoUser, SsoUser.class);
				} catch (IOException e) {
					e.printStackTrace();
					/* 登录过期，转入登录页面 */
					LOGGER.error("获取redis内用户失败vt({}) check false !", vt);
					this.validateFailed(backUrl, mv);
				}
			} else {
				/* 登录过期，转入登录页面 */
				LOGGER.info("vt({})获取用户失败!", vt);
				this.validateFailed(backUrl, mv);
			}
		} else {
			/* vt不存在，表示没有登录 */
			this.validateFailed(backUrl, mv);
		}
		return ssoUser;
	}
	
	/**
	 * <验证失败时，判断是否重新登录的操作>
	 * 
	 * @param backUrl
	 * @param mv
	 */
	public  void validateFailed(String backUrl, ModelAndView mv) {
		if (StringUtils.isNoneEmpty(backUrl)) {
			mv.addObject("backUrl", backUrl);
		}
		// 转到登录页面
		mv.setViewName(loginConfig.getLoginViewName());
	}

	
	/**
	 * <vt验证失败，生成vt，按需添加lt>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param backUrl
	 * @param ssoUser
	 * @param rememberMe
	 * @param mv
	 * @throws Exception
	 */
	public  void validateSucceed(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			String backUrl, SsoUser ssoUser, boolean rememberMe, ModelAndView mv) throws Exception {

		// 先将密码置空
		//ssoUser.setPassword("********");
		if (rememberMe) {
			/* rememberMe=true时，表示lt已失效 */
			// 重新生成lt
			String lt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
			// 添加ltcookie
			CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getLtCookieName(), lt, true);
			// 添加用户到redis
			redisService.set(lt, MAPPER.writeValueAsString(ssoUser), loginConfig.getLtRedisMaxTime());
			LOGGER.info("remember me new lt={}", lt);
		}
		// 生成vt
		String vt = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		// 添加vtcookie
		CookieUtil.setCookie(httpServletRequest, httpServletResponse, loginConfig.getVtCookieName(), vt, true);
		// 添加vt用户到redis
		redisService.set(vt, MAPPER.writeValueAsString(ssoUser), loginConfig.getVtRedisMaxTime());
		LOGGER.info("new vt={}", vt);
		if (StringUtils.isNotEmpty(backUrl)) {
			mv.setViewName("redirect:" + backUrl);
		} else {
			mv.setViewName("redirect:" + loginConfig.getPortalUrl());
		}

	}
}
